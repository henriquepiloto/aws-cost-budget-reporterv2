"""
Prisma Cost Intelligence Platform - Backend API
Cloudinho AI Assistant with authentication and admin panel
"""

import json
import boto3
import bcrypt
import jwt
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
import logging
import os

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Mock database for authentication
users_db = [
    {
        "id": "1",
        "email": "admin@selectsolucoes.com",
        "password": "$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi",  # password
        "name": "Administrador",
        "role": "admin",
        "mfaEnabled": False,
        "createdAt": datetime.now().isoformat(),
        "lastLogin": datetime.now().isoformat()
    }
]

chat_config = {
    "primaryColor": "#3b82f6",
    "secondaryColor": "#1e40af",
    "botName": "Cloudinho",
    "welcomeMessage": "Olá! Sou o Cloudinho, seu assistente de análise de custos AWS. Como posso ajudar você hoje?",
    "theme": "light"
}

JWT_SECRET = os.getenv('JWT_SECRET', 'your-secret-key')

class CloudinhoAssistant:
    """Cloudinho - AI Assistant for AWS Cost Intelligence"""
    
    def __init__(self):
        self.bedrock = boto3.client('bedrock-runtime', region_name='us-east-1')
        self.model_id = 'anthropic.claude-3-sonnet-20240229-v1:0'
        
    def ask(self, question: str) -> str:
        """Process user question with Cloudinho's personality"""
        try:
            prompt = f"""Você é o Cloudinho, um assistente especializado em análise de custos AWS. 
            Responda de forma clara e objetiva sobre otimização de custos, melhores práticas e análise financeira na AWS.
            
            Pergunta do usuário: {question}
            
            Resposta:"""
            
            response = self.bedrock.invoke_model(
                modelId=self.model_id,
                body=json.dumps({
                    'anthropic_version': 'bedrock-2023-05-31',
                    'max_tokens': 1000,
                    'messages': [
                        {
                            'role': 'user',
                            'content': prompt
                        }
                    ]
                })
            )
            
            response_body = json.loads(response['body'].read())
            return response_body['content'][0]['text']
            
        except Exception as e:
            logger.error(f"Cloudinho error: {e}")
            return f"Desculpe, estou com dificuldades técnicas no momento. Como posso ajudar com análise de custos AWS? Erro: {str(e)}"

def verify_token(token: str) -> Optional[Dict]:
    """Verify JWT token"""
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
        return payload
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

def lambda_handler(event, context):
    """Main Lambda handler"""
    try:
        # Parse request
        http_method = event.get('httpMethod', 'GET')
        path = event.get('path', '/')
        query_params = event.get('queryStringParameters') or {}
        body = event.get('body')
        headers_in = event.get('headers') or {}
        
        # Parse body if present
        request_data = {}
        if body:
            try:
                request_data = json.loads(body)
            except:
                pass
        
        # CORS headers
        headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,Authorization',
            'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
            'Content-Type': 'application/json'
        }
        
        # Handle OPTIONS (CORS preflight)
        if http_method == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({'message': 'CORS preflight'})
            }
        
        # Initialize Cloudinho
        cloudinho = CloudinhoAssistant()
        
        # Route requests
        if path == '/auth/login':
            email = request_data.get('email')
            password = request_data.get('password')
            
            if not email or not password:
                return {
                    'statusCode': 400,
                    'headers': headers,
                    'body': json.dumps({'message': 'Email e senha são obrigatórios'})
                }
            
            user = next((u for u in users_db if u["email"] == email), None)
            
            if not user:
                return {
                    'statusCode': 401,
                    'headers': headers,
                    'body': json.dumps({'message': 'Credenciais inválidas'})
                }
            
            if not bcrypt.checkpw(password.encode('utf-8'), user["password"].encode('utf-8')):
                return {
                    'statusCode': 401,
                    'headers': headers,
                    'body': json.dumps({'message': 'Credenciais inválidas'})
                }
            
            if user.get("mfaEnabled"):
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps({'requiresMFA': True, 'message': 'Código MFA necessário'})
                }
            
            token = jwt.encode({
                "userId": user["id"],
                "email": user["email"],
                "role": user["role"],
                "exp": datetime.utcnow() + timedelta(hours=24)
            }, JWT_SECRET, algorithm='HS256')
            
            user["lastLogin"] = datetime.now().isoformat()
            
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({
                    "token": token,
                    "user": {
                        "id": user["id"],
                        "email": user["email"],
                        "name": user["name"],
                        "role": user["role"]
                    }
                })
            }
        
        elif path == '/auth/verify':
            auth_header = headers_in.get('authorization') or headers_in.get('Authorization')
            if not auth_header or not auth_header.startswith('Bearer '):
                return {
                    'statusCode': 401,
                    'headers': headers,
                    'body': json.dumps({'message': 'Token não fornecido'})
                }
            
            token = auth_header.replace('Bearer ', '')
            user_data = verify_token(token)
            
            if not user_data:
                return {
                    'statusCode': 401,
                    'headers': headers,
                    'body': json.dumps({'message': 'Token inválido'})
                }
            
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({'valid': True, 'user': user_data})
            }
        
        elif path == '/admin/users':
            auth_header = headers_in.get('authorization') or headers_in.get('Authorization')
            if not auth_header or not auth_header.startswith('Bearer '):
                return {
                    'statusCode': 401,
                    'headers': headers,
                    'body': json.dumps({'message': 'Token não fornecido'})
                }
            
            token = auth_header.replace('Bearer ', '')
            user_data = verify_token(token)
            
            if not user_data or user_data.get("role") != "admin":
                return {
                    'statusCode': 403,
                    'headers': headers,
                    'body': json.dumps({'message': 'Acesso negado'})
                }
            
            if http_method == 'GET':
                safe_users = [{k: v for k, v in user.items() if k != "password"} for user in users_db]
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps({"users": safe_users})
                }
            
            elif http_method == 'POST':
                email = request_data.get('email')
                name = request_data.get('name')
                role = request_data.get('role')
                
                if not email or not name or not role:
                    return {
                        'statusCode': 400,
                        'headers': headers,
                        'body': json.dumps({'message': 'Dados obrigatórios não fornecidos'})
                    }
                
                if any(u["email"] == email for u in users_db):
                    return {
                        'statusCode': 400,
                        'headers': headers,
                        'body': json.dumps({'message': 'Email já cadastrado'})
                    }
                
                temp_password = "temp123"
                hashed_password = bcrypt.hashpw(temp_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
                
                new_user = {
                    "id": str(len(users_db) + 1),
                    "email": email,
                    "name": name,
                    "role": role,
                    "password": hashed_password,
                    "mfaEnabled": False,
                    "createdAt": datetime.now().isoformat()
                }
                
                users_db.append(new_user)
                
                safe_user = {k: v for k, v in new_user.items() if k != "password"}
                return {
                    'statusCode': 201,
                    'headers': headers,
                    'body': json.dumps({
                        "user": safe_user,
                        "tempPassword": temp_password,
                        "message": "Usuário criado com sucesso"
                    })
                }
        
        elif path == '/admin/config':
            auth_header = headers_in.get('authorization') or headers_in.get('Authorization')
            
            if http_method == 'GET':
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps({"config": chat_config})
                }
            
            if not auth_header or not auth_header.startswith('Bearer '):
                return {
                    'statusCode': 401,
                    'headers': headers,
                    'body': json.dumps({'message': 'Token não fornecido'})
                }
            
            token = auth_header.replace('Bearer ', '')
            user_data = verify_token(token)
            
            if not user_data or user_data.get("role") != "admin":
                return {
                    'statusCode': 403,
                    'headers': headers,
                    'body': json.dumps({'message': 'Acesso negado'})
                }
            
            if http_method == 'PUT':
                global chat_config
                if request_data.get('primaryColor'):
                    chat_config["primaryColor"] = request_data['primaryColor']
                if request_data.get('secondaryColor'):
                    chat_config["secondaryColor"] = request_data['secondaryColor']
                if request_data.get('botName'):
                    chat_config["botName"] = request_data['botName']
                if request_data.get('welcomeMessage'):
                    chat_config["welcomeMessage"] = request_data['welcomeMessage']
                if request_data.get('theme'):
                    chat_config["theme"] = request_data['theme']
                
                return {
                    'statusCode': 200,
                    'headers': headers,
                    'body': json.dumps({
                        "config": chat_config,
                        "message": "Configuração atualizada com sucesso"
                    })
                }
        
        elif path == '/chat/config':
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({"config": chat_config})
            }
        
        elif path == '/chat':
            message = request_data.get('message', '')
            
            if not message:
                return {
                    'statusCode': 400,
                    'headers': headers,
                    'body': json.dumps({'error': 'Message is required'})
                }
            
            response = cloudinho.ask(message)
            
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({
                    'response': response,
                    'timestamp': datetime.now().isoformat()
                })
            }
        
        else:
            return {
                'statusCode': 404,
                'headers': headers,
                'body': json.dumps({'error': 'Endpoint not found'})
            }
    
    except Exception as e:
        logger.error(f"Lambda error: {e}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'message': str(e)
            })
        }

# For local testing
def handler(event, context):
    return lambda_handler(event, context)
